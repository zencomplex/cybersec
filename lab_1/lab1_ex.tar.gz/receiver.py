from scapy.all import *
import sys


def get_packet(packet):
    print(chr(packet[ARP].hwlen))

packets = sniff(filter='arp', prn=get_packet)

wrpcap('evil.pcap', packets)
