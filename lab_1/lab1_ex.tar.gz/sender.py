from scapy.all import *
import sys

ip_addr = sys.argv[1]
msg = sys.argv[2]

for c in msg:
    pkt = Ether()/ARP(pdst=ip_addr, hwlen=ord(c))
    sendp(pkt)
